from Crypto.Util.number import *
from secret import flag
import hashlib, random

assert flag.startswith(b'Spirit{')
assert len(flag) == 64

pbits = 360
nbits = 3840
n = 16

primes = [getPrime(pbits) for _ in range(n)]
secrets = [getRandomNBitInteger(nbits) for _ in range(n)]
secrets.sort()

data = []

for p in primes:
    tmp = [s % p for s in secrets]
    random.shuffle(tmp)
    data.append(tmp)

def encrypt(pt, secrets):
    return bytes(x ^ y for x, y in zip(pt, hashlib.sha512(str(list(secrets)).encode()).digest()))

ct = encrypt(flag, secrets)

with open("output.txt", "w") as f:
    print(f"{primes = }", file = f)
    print(f"{data = }", file = f)
    print(f"{ct = }", file = f)
