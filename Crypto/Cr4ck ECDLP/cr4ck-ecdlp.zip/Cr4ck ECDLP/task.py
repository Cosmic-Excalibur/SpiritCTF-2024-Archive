import os
import random
from secret import a, b, p, flag, Px0, Py0

bits = lambda x: list(map(int, bin(x)[2:][::-1]))

def add(P, Q):
    if P is None or Q is None:
        return P or Q
    xp, yp = P
    xq, yq = Q
    if xp == xq:
        if yp == yq:
            return double(P)
        else:
            return None
    m = (yp - yq) * pow(xp - xq, -1, p) % p
    xr = (m**2 - xp - xq) % p
    yr = (yp + m * (xr - xp)) % p
    return (xr % p, (-yr) % p)

def double(P): 
    if P is None:
        return None 
    xp, yp = P 
    m = (3 * xp ** 2 + a) * pow(2 * yp, -1, p) % p
    xr = (m**2 - 2*xp) % p
    yr = (yp + m * (xr - xp)) % p
    return (xr % p, (-yr) % p)

def mul(n, P):
    result = None
    addend = P
    for b in bits(n):
        if b:
            result = add(result, addend)
        addend = double(addend)
    return result

banner = """
 @@@@@@@@ @@     @@ @@     @@ @@   @@
/@@///// //@@   @@ //@@   @@ /@@  @@ 
/@@       //@@ @@   //@@ @@  /@@ @@  
/@@@@@@@   //@@@     //@@@   /@@@@   
/@@////     @@/@@     @@/@@  /@@/@@  
/@@        @@ //@@   @@ //@@ /@@//@@ 
/@@       @@   //@@ @@   //@@/@@ //@@
//       //     // //     // //   // 

 @@@@@@@@   @@@@@@  @@@@@@@   @@       @@@@@@@ 
/@@/////   @@////@@/@@////@@ /@@      /@@////@@
/@@       @@    // /@@    /@@/@@      /@@   /@@
/@@@@@@@ /@@       /@@    /@@/@@      /@@@@@@@ 
/@@////  /@@       /@@    /@@/@@      /@@////  
/@@      //@@    @@/@@    @@ /@@      /@@      
/@@@@@@@@ //@@@@@@ /@@@@@@@  /@@@@@@@@/@@      
////////   //////  ///////   //////// //           


"""

TRIALS_1 = 30
TRIALS_2 = 3

print(banner)
print("Prove that ECDLP is super ez to crack!")
print("Provide your point `P`, and I'll give you the result (x-coordinate) of `Q = s*P`.")

assert (Px0**3 + a*Px0 + b - Py0**2) % p == 0
print("For example, if `P = (%s, %s)`:" % (Px0, Py0))
for s in range(2, 7):
    print("For `s = %s`, `Q = s*P = (%s, %s)`." % (s, *mul(s, (Px0, Py0))))

s = random.randint(0, p - 1)

while True:
    print()
    if TRIALS_1 <= 0 or TRIALS_2 <= 0:
        print("You lose :p")
        print("Bye~~~")
        exit()
    
    print("[%03d] 1. Submit your point `P`." % TRIALS_1)
    print("[%03d] 2. Guess my secret!" % TRIALS_2)
    
    option = input(">>> ").strip()
    
    if option == '1':
        print("Format: `Px, Py`.")
        line = input("P = ").strip()
        try:
            Px, Py = [int(x.strip()) for x in line.split(',')]
            P = (Px, Py)
            res = mul(s, P)
            if res == None:
                Qx = "Infinity"
            else:
                Qx, Qy = res
            print("Qx =", Qx)
            TRIALS_1 -= 1
        except (AssertionError, ValueError):
            print("Invalid input :(")
            continue
    elif option == '2':
        try:
            s_ = int(input("s = ").strip())
            if s == s_:
                print("Congratulations, you have just cracked the invincible ECDLP!!!")
                print("Claim your spoil:")
                print(flag)
                exit()
            else:
                print("Oops, that's not correct. Try harder :)")
            TRIALS_2 -= 1
        except ValueError:
            print("Invalid input :(")
            continue
    else:
        print("Invalid input :(")
        continue