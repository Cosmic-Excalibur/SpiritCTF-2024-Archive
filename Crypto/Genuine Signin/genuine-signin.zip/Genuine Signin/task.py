from secret import flag
from Crypto.Util.number import *
import random
# pip install pycryptodome

assert len(flag) < 511
assert flag.startswith(b'Spirit{') and flag.endswith(b'}')

pad = lambda m, l: m + (b'\x00' + random.randbytes(max(0, l - len(m) - 1)) if len(m) < l else b'')
unpad = lambda m: m[:m.index(0)] if 0 in m else m

flag = pad(flag, 511)
m = bytes_to_long(flag)

e = 3
while True:
    p = getPrime(2048)
    q = getPrime(2048)
    N = p * q
    phi = (p-1) * (q-1)
    if GCD(phi, e) == 1: break
d = pow(e, -1, phi)
c = pow(m, e, N)

a = pow(phi, 3, N)
b = pow(d, 3, N)

with open("output.txt", "w") as f:
    print(f"{e = }", file = f)
    print(f"{N = }", file = f)
    print(f"{c = }", file = f)
    print(f"{a = }", file = f)
    print(f"{b = }", file = f)
