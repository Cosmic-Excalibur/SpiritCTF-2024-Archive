from secret import flag, secret
import random
import hashlib
import pickle

assert flag.startswith(b'Spirit{') and flag.endswith(b'}')
assert len(flag) <= 128

N = 233333
assert isinstance(secret, list)
assert len(set(secret)) == N
assert min(secret) == 0 and max(secret) == N - 1

class FeatherStitching:
    def __init__(self, stitching):
        self.stitching = list(stitching)
        self.unstitching = None
        
        # sanity check (slooooooowwww)
        # assert set(self.stitching) == set(range(N))
    
    def __mul__(self, other):
        new = FeatherStitching([other.stitching[s] for s in self.stitching])
        return new
    
    def __pow__(self, n):
        new = UNIT
        if n == 0: return UNIT
        if n > 0:
            double = self
        else:
            double = self.inverse()
            n = -n
        while n > 0:
            if n & 1:
                new *= double
            double *= double
            n >>= 1
        return new

    def inverse(self):
        if self.unstitching == None:
            self.unstitching = [0]*N
            for i, j in enumerate(stitching):
                self.unstitching[j] = i
        return FeatherStitching(self.unstitching)
    
    def __eq__(self, other):
        return self.stitching == other.stitching
    
    def __repr__(self):
        return 'FeatherStitching(%s)' % repr(self.stitching)
        
    def __str__(self):
        return 'FeatherStitching(%s)' % str(self.stitching)
    
    def __reduce__(self):
        return (self.__class__, (self.stitching,))

UNIT = FeatherStitching(range(N))

pad = lambda m, l: m + bytes(random.randrange(256)*bool(i) for i in range(l - len(m)))
unpad = lambda m: m[:m.index(0)] if 0 in m else m
flag = pad(flag, 128)

fs = FeatherStitching(secret)

gift = fs**1337133713371337133713371337713371337133713371337133702

with open("gift.pickle", "wb") as f:
    pickle.dump(gift, f)

def stitch(msg, stitching):
    assert len(msg) == 128
    return bytes(a ^ b for a, b in zip(msg, hashlib.sha512(' :p '.join(map(str, stitching.stitching)).encode()).digest() + hashlib.sha512(' XD '.join(map(str, stitching.stitching)).encode()).digest()))

ct = stitch(flag, fs)

with open("ct.txt", "w") as f:
    f.write(f"{ct = }")
